﻿namespace Ejeercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese la cantidad de números primos que desea generar: ");
            int cantidad = Convert.ToInt32(Console.ReadLine());

            int numero = 2;
            int contador = 0;

            while (contador < cantidad) {
                if (EsPrimo(numero))
                {
                    Console.WriteLine(numero + "  ");
                    contador++;
                }
                numero ++;
            }
        }

        static bool EsPrimo(int num) {
        if (num <= 1) {
            return false;
            
            }
        for (int i = 2; i <= Math.Sqrt(num); i++)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }
        return true;
        }
    }
}
