﻿namespace Ejercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el primer número: ");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el segundo número: ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el tercer número: ");
            int num3 = Convert.ToInt32(Console.ReadLine());

            int mayor = num1;
            int menor = num1;

            if(num2 > mayor)
            {
                mayor = num2;
            }
            else if(num2 < menor) {
                menor = num2; 
            }
            if(num3 > mayor)
            {
                mayor = num3;
            }
            else if (num3 < menor)
            {
                menor = num3;
            }
            Console.WriteLine("El número mayor es: " + mayor);
            Console.WriteLine("El número menor es: " + menor);
        }
    }
}
