﻿namespace Ejercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 50; i++)
            {
                if (i != 25)
                {
                    Console.WriteLine(i);
                }

            }
        }
    }
}
