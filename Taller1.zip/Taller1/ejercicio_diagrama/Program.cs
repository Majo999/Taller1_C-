﻿
class Program {
    static void Main(string[] args) {
        Console.WriteLine("Escribe la cantidad de empleados");
        int cantidadEmpleados = int.Parse(Console.ReadLine());
        double sumaSueldos = 0;
        double retenidos = 0;

        for (int i = 1; i <= cantidadEmpleados; i++){
            Console.WriteLine("Escribe el sueldo base del empleado");
            double sueldoBase = double.Parse(Console.ReadLine());
            double retenido = (sueldoBase * 0.10) + (sueldoBase * 0.05) + (sueldoBase * 0.04);
            double sueldoTotal = sueldoBase + retenido;

            sumaSueldos += sueldoTotal;
            retenidos += retenido;

            Console.WriteLine("El sueldo neto es {0}", sueldoTotal);
        }

        Console.WriteLine("El total de los sueldos es {0}", sumaSueldos);
        Console.WriteLine("El total de los retenidos es {0}", retenidos);
    }
}
